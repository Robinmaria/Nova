package com.nova.mockup;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout messages;
    EditText input;

    TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE);
        t.setPadding(18, 12, 18, 12);
        return t;
    }

    GradientDrawable background(String c, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(c)); g.setCornerRadius(r);
        return g;
    }

    void bubble(String s, boolean me) {
        TextView b = text(s, 16);
        b.setBackground(background(me ? "#1B6DFF" : "#151A28", 36));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(me ? 80 : 8, 8, me ? 8 : 80, 8);
        b.setLayoutParams(p);
        messages.addView(b);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 24, 16, 16);
        root.setBackgroundColor(Color.parseColor("#070A12"));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("NOVA", 26);
        title.setTypeface(null, 1);
        TextView online = text("● ONLINE", 12);
        online.setTextColor(Color.parseColor("#78F0A7"));
        header.addView(title, new LinearLayout.LayoutParams(0,-2,1));
        header.addView(online);
        root.addView(header);

        TextView orb = text("✦", 72);
        orb.setGravity(Gravity.CENTER);
        orb.setTextColor(Color.parseColor("#75A7FF"));
        GradientDrawable orbBg = background("#0D1730", 150);
        orbBg.setStroke(3, Color.parseColor("#397BFF"));
        orb.setBackground(orbBg);
        LinearLayout.LayoutParams orbParams = new LinearLayout.LayoutParams(180,180);
        orbParams.gravity = Gravity.CENTER;
        orbParams.setMargins(0,36,0,16);
        root.addView(orb, orbParams);

        TextView greeting = text("Good evening.\nI'm ready.", 24);
        greeting.setGravity(Gravity.CENTER);
        root.addView(greeting);

        ScrollView scroll = new ScrollView(this);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(0,18,0,10);
        scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        bubble("Hi. I'm Nova. What would you like me to do?", false);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Talk to Nova...");
        input.setHintTextColor(Color.parseColor("#7C8499"));
        input.setTextColor(Color.WHITE);
        input.setTextSize(16);
        input.setBackground(background("#151A28",40));
        input.setPadding(20,0,15,0);
        bar.addView(input,new LinearLayout.LayoutParams(0,58,1));

        Button send = new Button(this);
        send.setText("➤");
        send.setTextColor(Color.WHITE);
        send.setTextSize(20);
        send.setBackground(background("#1B6DFF",40));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(64,58);
        sp.setMargins(8,0,0,0);
        bar.addView(send,sp);
        root.addView(bar);

        View.OnClickListener action = v -> {
            String q=input.getText().toString().trim();
            if(q.isEmpty()) return;
            bubble(q,true);
            input.setText("");
            new Handler().postDelayed(() ->
                bubble("Understood. I'm running in mockup mode for now.",false),400);
        };
        send.setOnClickListener(action);
        input.setOnEditorActionListener((v,a,e) -> { action.onClick(v); return true; });
        setContentView(root);
    }
}
